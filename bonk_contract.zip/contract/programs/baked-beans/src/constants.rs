pub const GLOBAL_STATE_SEED: &[u8] = b"GLOBAL_STATE_SEED";

pub const USER_STATE_SEED: &[u8] = b"USER_STATE_SEED";

pub const VAULT_SEED: &[u8] = b"VAULT_SEED";
